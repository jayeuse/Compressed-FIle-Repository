﻿Imports MySql.Data.MySqlClient

Public Class formUsingDatabase

    Dim mysqlCommand As New MySqlCommand
    Dim dataTable As New DataTable
    Dim dataAdapter As New MySqlDataAdapter
    Dim str As String
    Dim x As Integer
    Dim mysqlConnection As New MySqlConnection(
            "server=localhost;
            user=root;
            database=sales;")
    Private Sub formUsingDatabase_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub buttonShowRecords_Click(sender As Object, e As EventArgs) Handles buttonShowRecords.Click
        dataTable.Clear()
        str = "select * from product"
        mysqlConnection.Open()
        mysqlCommand.Connection = mysqlConnection
        mysqlCommand.CommandText = str
        dataAdapter.SelectCommand = mysqlCommand
        dataAdapter.Fill(dataTable)
        DGViewTable.DataSource = dataTable
        mysqlConnection.Close()
    End Sub

    Private Sub buttonExit_Click(sender As Object, e As EventArgs) Handles buttonExit.Click

    End Sub

    Private Sub DGViewTable_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGViewTable.CellContentClick

    End Sub

    Private Sub DGViewTable_MouseClick(sender As Object, e As MouseEventArgs) Handles DGViewTable.MouseClick
        viewTable()
    End Sub

    Private Sub DGViewTable_KeyDown(sender As Object, e As KeyEventArgs) Handles DGViewTable.KeyDown
        viewTable()
    End Sub

    Public Sub viewTable()

        Try
            Try
                Dim current_row As Integer = DGViewTable.CurrentRow.Index
                textboxProductID.Text = DGViewTable.Item(0, current_row).Value
                textboxProductName.Text = DGViewTable.Item(1, current_row).Value
                textboxQuantity.Text = DGViewTable.Item(2, current_row).Value
            Catch ex As Exception
                MsgBox("End of Records")
            End Try
        Catch ex As Exception
            MsgBox("Click on the table to view records")
        End Try

    End Sub

    Private Sub buttonAdd_Click(sender As Object, e As EventArgs) Handles buttonAdd.Click
        x = 1
        addRecord()

        textboxProductID.Text = ""
        textboxProductName.Text = ""
        textboxQuantity.Text = ""
    End Sub

    Public Sub addRecord()
        textboxProductID.Enabled = True
        textboxProductName.Enabled = True
        textboxQuantity.Enabled = True

        buttonSave.Enabled = True
        buttonCancel.Enabled = True

        buttonAdd.Enabled = False
        buttonEdit.Enabled = False
        buttonDelete.Enabled = False

        buttonSearch.Enabled = False
    End Sub

    Public Sub disableRecords()
        textboxProductID.Enabled = False
        textboxProductName.Enabled = False
        textboxQuantity.Enabled = False

        buttonSave.Enabled = False
        buttonCancel.Enabled = False

        buttonAdd.Enabled = True
        buttonEdit.Enabled = True
        buttonDelete.Enabled = True

        buttonSearch.Enabled = True
    End Sub

    Private Sub buttonCancel_Click(sender As Object, e As EventArgs) Handles buttonCancel.Click
        disableRecords()
    End Sub

    Private Sub buttonSave_Click(sender As Object, e As EventArgs) Handles buttonSave.Click
        mysqlConnection.Open()
        If x = 1 Then
            str = "insert into product values('" & textboxProductID.Text & "','" & textboxProductName.Text & "','" & textboxQuantity.Text & "')"
        End If

        mysqlCommand.Connection = mysqlConnection
        mysqlCommand.CommandText = str
        mysqlCommand.ExecuteNonQuery()
        mysqlConnection.Close()
        disableRecords()
        viewTable()
    End Sub
End Class
