﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formUsingDatabase
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        buttonShowRecords = New Button()
        buttonExit = New Button()
        DGViewTable = New DataGridView()
        textboxProductID = New TextBox()
        textboxProductName = New TextBox()
        textboxQuantity = New TextBox()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        buttonAdd = New Button()
        buttonEdit = New Button()
        buttonDelete = New Button()
        buttonSave = New Button()
        buttonCancel = New Button()
        buttonSearch = New Button()
        CType(DGViewTable, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(416, 24)
        Label1.Name = "Label1"
        Label1.Size = New Size(211, 31)
        Label1.TabIndex = 0
        Label1.Text = "ABC PRODUCT LIST"
        ' 
        ' buttonShowRecords
        ' 
        buttonShowRecords.Location = New Point(143, 73)
        buttonShowRecords.Name = "buttonShowRecords"
        buttonShowRecords.Size = New Size(140, 64)
        buttonShowRecords.TabIndex = 1
        buttonShowRecords.Text = "Show Records"
        buttonShowRecords.UseVisualStyleBackColor = True
        ' 
        ' buttonExit
        ' 
        buttonExit.Location = New Point(775, 73)
        buttonExit.Name = "buttonExit"
        buttonExit.Size = New Size(140, 64)
        buttonExit.TabIndex = 2
        buttonExit.Text = "Exit"
        buttonExit.UseVisualStyleBackColor = True
        ' 
        ' DGViewTable
        ' 
        DGViewTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DGViewTable.Location = New Point(143, 155)
        DGViewTable.Name = "DGViewTable"
        DGViewTable.RowHeadersWidth = 51
        DGViewTable.Size = New Size(772, 288)
        DGViewTable.TabIndex = 3
        ' 
        ' textboxProductID
        ' 
        textboxProductID.Enabled = False
        textboxProductID.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        textboxProductID.Location = New Point(284, 449)
        textboxProductID.Name = "textboxProductID"
        textboxProductID.Size = New Size(215, 34)
        textboxProductID.TabIndex = 4
        ' 
        ' textboxProductName
        ' 
        textboxProductName.Enabled = False
        textboxProductName.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        textboxProductName.Location = New Point(284, 489)
        textboxProductName.Name = "textboxProductName"
        textboxProductName.Size = New Size(391, 34)
        textboxProductName.TabIndex = 5
        ' 
        ' textboxQuantity
        ' 
        textboxQuantity.Enabled = False
        textboxQuantity.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        textboxQuantity.Location = New Point(284, 529)
        textboxQuantity.Name = "textboxQuantity"
        textboxQuantity.Size = New Size(215, 34)
        textboxQuantity.TabIndex = 6
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(164, 452)
        Label2.Name = "Label2"
        Label2.Size = New Size(58, 28)
        Label2.TabIndex = 7
        Label2.Text = "Code"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(164, 492)
        Label3.Name = "Label3"
        Label3.Size = New Size(64, 28)
        Label3.TabIndex = 8
        Label3.Text = "Name"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(164, 532)
        Label4.Name = "Label4"
        Label4.Size = New Size(88, 28)
        Label4.TabIndex = 9
        Label4.Text = "Quantity"
        ' 
        ' buttonAdd
        ' 
        buttonAdd.ForeColor = Color.Red
        buttonAdd.Location = New Point(164, 589)
        buttonAdd.Name = "buttonAdd"
        buttonAdd.Size = New Size(102, 40)
        buttonAdd.TabIndex = 10
        buttonAdd.Text = "Add"
        buttonAdd.UseVisualStyleBackColor = True
        ' 
        ' buttonEdit
        ' 
        buttonEdit.Location = New Point(272, 589)
        buttonEdit.Name = "buttonEdit"
        buttonEdit.Size = New Size(102, 40)
        buttonEdit.TabIndex = 11
        buttonEdit.Text = "Edit"
        buttonEdit.UseVisualStyleBackColor = True
        ' 
        ' buttonDelete
        ' 
        buttonDelete.Location = New Point(380, 589)
        buttonDelete.Name = "buttonDelete"
        buttonDelete.Size = New Size(102, 40)
        buttonDelete.TabIndex = 12
        buttonDelete.Text = "Delete"
        buttonDelete.UseVisualStyleBackColor = True
        ' 
        ' buttonSave
        ' 
        buttonSave.Enabled = False
        buttonSave.Location = New Point(703, 589)
        buttonSave.Name = "buttonSave"
        buttonSave.Size = New Size(102, 40)
        buttonSave.TabIndex = 13
        buttonSave.Text = "Save"
        buttonSave.UseVisualStyleBackColor = True
        ' 
        ' buttonCancel
        ' 
        buttonCancel.Enabled = False
        buttonCancel.Location = New Point(811, 589)
        buttonCancel.Name = "buttonCancel"
        buttonCancel.Size = New Size(102, 40)
        buttonCancel.TabIndex = 14
        buttonCancel.Text = "Cancel"
        buttonCancel.UseVisualStyleBackColor = True
        ' 
        ' buttonSearch
        ' 
        buttonSearch.Location = New Point(811, 452)
        buttonSearch.Name = "buttonSearch"
        buttonSearch.Size = New Size(102, 40)
        buttonSearch.TabIndex = 15
        buttonSearch.Text = "Search"
        buttonSearch.UseVisualStyleBackColor = True
        ' 
        ' formUsingDatabase
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.InactiveCaption
        ClientSize = New Size(1085, 663)
        Controls.Add(buttonSearch)
        Controls.Add(buttonCancel)
        Controls.Add(buttonSave)
        Controls.Add(buttonDelete)
        Controls.Add(buttonEdit)
        Controls.Add(buttonAdd)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(textboxQuantity)
        Controls.Add(textboxProductName)
        Controls.Add(textboxProductID)
        Controls.Add(DGViewTable)
        Controls.Add(buttonExit)
        Controls.Add(buttonShowRecords)
        Controls.Add(Label1)
        Name = "formUsingDatabase"
        Text = "Using Database"
        CType(DGViewTable, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents buttonShowRecords As Button
    Friend WithEvents buttonExit As Button
    Friend WithEvents DGViewTable As DataGridView
    Friend WithEvents textboxProductID As TextBox
    Friend WithEvents textboxProductName As TextBox
    Friend WithEvents textboxQuantity As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents buttonAdd As Button
    Friend WithEvents buttonEdit As Button
    Friend WithEvents buttonDelete As Button
    Friend WithEvents buttonSave As Button
    Friend WithEvents buttonCancel As Button
    Friend WithEvents buttonSearch As Button

End Class
